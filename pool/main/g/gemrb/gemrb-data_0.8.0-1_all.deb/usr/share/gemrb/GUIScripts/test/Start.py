import GemRB
def OnLoad():
	GemRB.Quit()
